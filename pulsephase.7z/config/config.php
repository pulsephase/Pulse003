<?php

define('DEBUG', true);

define('DEFAULT_CONTROLLER','Home'); // default controller if no url controllers defined
define('DEFAULT_LAYOUT', 'default'); // if no layout is set in the controller use this layout
define('PROOT', '/pulsephase/'); // set this to project root path
define('SITE_TITLE', 'PULSEPHASE MVC');