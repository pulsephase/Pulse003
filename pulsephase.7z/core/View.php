<?php

class View {
	protected $_head, $_body, $_siteTitle, $_outputBuffer, $_layout = DEFAULT_LAYOUT;
	public function __construct(){
		
	}
	
	public function render($viewName){
		
	}
}